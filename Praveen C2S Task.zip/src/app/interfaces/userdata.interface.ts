export interface userData {
address_proof: string
adhaar_card: string
age_crop: string
alternate_number: string
country_name: string
crop_type: string
district_name: string
education: string
farmers_name: string
field_area: string
field_name: string
house_address: string
id_number: string
land_mark: string
mmandal_name: string
no_of_trees: string
phone_number: string
phone_type: string
photo_id: string
pincode: string
prefer_language: string
state_name: string
village_name: string
whatsapp_number: string
}